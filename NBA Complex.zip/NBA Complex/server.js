const express = require('express')
const cors = require('cors')
const app = express()
const PORT = 4523

let nbaPlayers ={
  'Lebron James': {
  'age': 36,
  'salary': `39.22Million`
},
  'Anthony Davis':{
    'age': 28,
    'salary': '27.09Million'
  },
  'Kyles Kuzma':{
    'age': 25,
    'salary': '13.1Million'
  },
  'unknown':{
    'age': 25,
    'salary': 'TOO MUCCH'
  }
}
app.use(cors())

app.get('/', (request, response) => {
  response.sendFile(__dirname + '/soccer.html')
})

app.get('/api/nbaPlayers', (request, response) =>{
  response.json(nbaPlayers)
})

app.listen(PORT, ()=>{
  console.log(`We playing Ba-sket-BALL!! server running on port ${PORT}`);
})
